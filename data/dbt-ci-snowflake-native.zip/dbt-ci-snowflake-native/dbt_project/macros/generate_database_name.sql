{# 
  CI実行時に var('target_database') が指定されていれば、それを優先する。
  本番ではvar未指定なのでprofiles.ymlのdatabaseが使われる。
#}
{% macro generate_database_name(custom_database_name=none, node=none) -%}
    {%- if var('target_database', none) is not none -%}
        {{ var('target_database') }}
    {%- elif custom_database_name is not none -%}
        {{ custom_database_name | trim }}
    {%- else -%}
        {{ target.database }}
    {%- endif -%}
{%- endmacro %}
