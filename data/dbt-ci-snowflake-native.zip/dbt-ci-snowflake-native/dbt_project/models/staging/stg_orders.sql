{{ config(materialized='view') }}

with source as (
    select * from {{ ref('raw_orders') }}
),

renamed as (
    select
        order_id,
        customer_id,
        cast(order_date as date) as order_date,
        cast(amount as numeric(10, 2)) as amount,
        lower(status) as status
    from source
)

select * from renamed
