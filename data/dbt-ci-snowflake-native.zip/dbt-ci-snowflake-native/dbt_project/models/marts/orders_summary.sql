{{ config(materialized='table') }}

with stg_orders as (
    select * from {{ ref('stg_orders') }}
),

aggregated as (
    select
        customer_id,
        count(*) as total_orders,
        count(case when status = 'completed' then 1 end) as completed_orders,
        sum(case when status = 'completed' then amount else 0 end) as total_spent,
        min(order_date) as first_order_date,
        max(order_date) as last_order_date
    from stg_orders
    group by customer_id
)

select * from aggregated
