#!/usr/bin/env bash
# =============================================================================
# deploy_prod.sh
# Phase 1: 本番にdbt projectをデプロイする
#
# 流れ:
#   1. mainブランチを最新にfetch
#   2. CREATE OR REPLACE DBT PROJECT で本番object更新
#   3. 動作確認 (compile)
#
# 実行タイミング:
#   - 初回構築時
#   - main ブランチへのmerge後 (CI/CD pipelineから呼ばれる)
# =============================================================================
set -euo pipefail

CONN="${SNOWFLAKE_CONNECTION:-prod}"

echo "===================================="
echo "Phase 1: Deploy dbt project to PROD"
echo "===================================="

# 1. Git Repository を最新化
echo "[1/3] Fetching latest from main branch..."
snow sql -c "$CONN" -q "ALTER GIT REPOSITORY PROD_DBT_DB.INTEGRATIONS.DBT_REPO FETCH;"

# 2. dbt project object を作成 or 更新
echo "[2/3] Deploying DBT PROJECT object..."
snow sql -c "$CONN" <<'SQL'
USE ROLE DBT_PROD_ROLE;
USE WAREHOUSE PROD_WH;

CREATE OR REPLACE DBT PROJECT PROD_DBT_DB.DEPLOYMENTS.DBT_PROJ_PROD
    FROM '@PROD_DBT_DB.INTEGRATIONS.DBT_REPO/branches/main/dbt_project/'
    EXTERNAL_ACCESS_INTEGRATIONS = (dbt_packages_eai)
    COMMENT = 'Production dbt project';
SQL

# 3. compile確認 (実行はしない)
echo "[3/3] Compiling project for validation..."
snow sql -c "$CONN" -q "EXECUTE DBT PROJECT PROD_DBT_DB.DEPLOYMENTS.DBT_PROJ_PROD ARGS='compile --target prod';"

echo ""
echo "✅ Deployment complete."
echo ""
echo "Next step: Run dbt build with"
echo "  snow sql -c $CONN -q \"EXECUTE DBT PROJECT PROD_DBT_DB.DEPLOYMENTS.DBT_PROJ_PROD ARGS='build --target prod'\""
