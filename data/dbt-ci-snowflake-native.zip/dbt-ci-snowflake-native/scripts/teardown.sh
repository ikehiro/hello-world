#!/usr/bin/env bash
# =============================================================================
# teardown.sh
# Phase 2: PR close時のクリーンアップ
#
# 削除対象:
#   - CI_DBT_DB.PR_OBJECTS.DBT_PROJ_PR_<番号>
#   - PR_<番号>_DB
# =============================================================================
set -euo pipefail

if [ -z "${PR_NUMBER:-}" ]; then
    echo "PR_NUMBER not set, skipping."
    exit 0
fi

KEY_FILE=$(mktemp /tmp/sf_key.XXXXXX.p8)
trap "shred -u ${KEY_FILE} 2>/dev/null || rm -f ${KEY_FILE}" EXIT
echo "${SNOWFLAKE_PRIVATE_KEY}" > "${KEY_FILE}"
chmod 600 "${KEY_FILE}"

export SNOWFLAKE_CONNECTIONS_CI_ACCOUNT="${SNOWFLAKE_ACCOUNT}"
export SNOWFLAKE_CONNECTIONS_CI_USER="${SNOWFLAKE_USER}"
export SNOWFLAKE_CONNECTIONS_CI_PRIVATE_KEY_FILE="${KEY_FILE}"
export SNOWFLAKE_CONNECTIONS_CI_ROLE="${SNOWFLAKE_ROLE}"
export SNOWFLAKE_CONNECTIONS_CI_WAREHOUSE="${SNOWFLAKE_WAREHOUSE}"
export SNOWFLAKE_CONNECTIONS_CI_AUTHENTICATOR="SNOWFLAKE_JWT"

echo "===================================="
echo "[Teardown] PR #${PR_NUMBER} cleanup"
echo "===================================="

snow sql -c ci -q "
DROP DBT PROJECT IF EXISTS CI_DBT_DB.PR_OBJECTS.DBT_PROJ_PR_${PR_NUMBER};
DROP DATABASE IF EXISTS PR_${PR_NUMBER}_DB;
"

echo "✅ PR #${PR_NUMBER} resources dropped"
