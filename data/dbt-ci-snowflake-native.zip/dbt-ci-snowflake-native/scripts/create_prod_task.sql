-- =============================================================================
-- create_prod_task.sql
-- Phase 3: 本番dbt projectを定期実行するTask
--
-- パターン:
--   - run と test を分けたDAG構成
--   - 失敗時はNotification Integration経由でSNS/メール通知
-- =============================================================================
USE ROLE DBT_PROD_ROLE;
USE DATABASE PROD_DBT_DB;
USE SCHEMA DEPLOYMENTS;

-- -----------------------------------------------------------------------------
-- メイン実行Task (毎日 02:00 JST)
-- -----------------------------------------------------------------------------
CREATE OR ALTER TASK DBT_PROD_RUN
    WAREHOUSE = PROD_WH
    SCHEDULE = 'USING CRON 0 2 * * * Asia/Tokyo'
    ERROR_INTEGRATION = email_notification_integration  -- 別途作成
    AS
EXECUTE DBT PROJECT PROD_DBT_DB.DEPLOYMENTS.DBT_PROJ_PROD
    ARGS='run --target prod';

-- -----------------------------------------------------------------------------
-- test Task (run成功後に実行)
-- -----------------------------------------------------------------------------
CREATE OR ALTER TASK DBT_PROD_TEST
    WAREHOUSE = PROD_WH
    AFTER DBT_PROD_RUN
    ERROR_INTEGRATION = email_notification_integration
    AS
EXECUTE DBT PROJECT PROD_DBT_DB.DEPLOYMENTS.DBT_PROJ_PROD
    ARGS='test --target prod';

-- -----------------------------------------------------------------------------
-- 有効化
-- -----------------------------------------------------------------------------
ALTER TASK DBT_PROD_TEST RESUME;
ALTER TASK DBT_PROD_RUN  RESUME;

-- 確認
SHOW TASKS IN SCHEMA PROD_DBT_DB.DEPLOYMENTS;

-- -----------------------------------------------------------------------------
-- 実行履歴とログ確認用クエリ
-- -----------------------------------------------------------------------------
-- 最近の実行履歴
SELECT *
FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY(
    SCHEDULED_TIME_RANGE_START => DATEADD('day', -7, CURRENT_TIMESTAMP())
))
WHERE NAME LIKE 'DBT_PROD%'
ORDER BY SCHEDULED_TIME DESC;

-- dbt実行ログ取得 (query_idはabove結果から)
-- SELECT SYSTEM$GET_DBT_LOG('<query_id>');
