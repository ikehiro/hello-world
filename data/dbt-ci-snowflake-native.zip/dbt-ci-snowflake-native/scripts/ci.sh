#!/usr/bin/env bash
# =============================================================================
# ci.sh
# Phase 2: PR時のCI実行スクリプト
#
# GitBucket CI Plugin の .gitbucket/ci.yml から呼ばれる。
# 
# 流れ:
#   1. PR用データDBを本番からzero-copy clone
#      → PR_<番号>_DB = CLONE PROD_DB
#   2. PR用dbt project objectをCIスキーマに作成
#      → CI_DBT_DB.PR_OBJECTS.dbt_proj_pr_<番号>
#   3. EXECUTE DBT PROJECT で build (PR_<番号>_DBにデータ書き込み)
#   4. 結果に応じてPRステータス反映
#
# 必須環境変数:
#   PR_NUMBER             : PRの番号
#   GIT_COMMIT_SHA        : commit SHA
#   GIT_BRANCH_NAME       : PR元のブランチ名 (例: feature/add-new-mart)
#   SNOWFLAKE_ACCOUNT
#   SNOWFLAKE_USER        = DBT_CI_USER
#   SNOWFLAKE_PRIVATE_KEY = (PEM全文)
#   SNOWFLAKE_ROLE        = CI_ROLE
#   SNOWFLAKE_WAREHOUSE   = CI_WH
# =============================================================================
set -euo pipefail

# -----------------------------------------------------------------------------
# 0. 変数準備
# -----------------------------------------------------------------------------
SHORT_SHA=$(echo "${GIT_COMMIT_SHA}" | cut -c1-12)
PR_DB="PR_${PR_NUMBER}_DB"
PR_PROJECT="DBT_PROJ_PR_${PR_NUMBER}"
PROJECT_FQN="CI_DBT_DB.PR_OBJECTS.${PR_PROJECT}"

echo "===================================="
echo "[CI] PR #${PR_NUMBER} / SHA ${SHORT_SHA}"
echo "  Branch:     ${GIT_BRANCH_NAME}"
echo "  Target DB:  ${PR_DB}"
echo "  Project:    ${PROJECT_FQN}"
echo "===================================="

# -----------------------------------------------------------------------------
# 1. Snowflake CLI接続設定 (一時的にconfig生成)
# -----------------------------------------------------------------------------
KEY_FILE=$(mktemp /tmp/sf_key.XXXXXX.p8)
trap "shred -u ${KEY_FILE} 2>/dev/null || rm -f ${KEY_FILE}" EXIT

echo "${SNOWFLAKE_PRIVATE_KEY}" > "${KEY_FILE}"
chmod 600 "${KEY_FILE}"

export SNOWFLAKE_CONNECTIONS_CI_ACCOUNT="${SNOWFLAKE_ACCOUNT}"
export SNOWFLAKE_CONNECTIONS_CI_USER="${SNOWFLAKE_USER}"
export SNOWFLAKE_CONNECTIONS_CI_PRIVATE_KEY_FILE="${KEY_FILE}"
export SNOWFLAKE_CONNECTIONS_CI_ROLE="${SNOWFLAKE_ROLE}"
export SNOWFLAKE_CONNECTIONS_CI_WAREHOUSE="${SNOWFLAKE_WAREHOUSE}"
export SNOWFLAKE_CONNECTIONS_CI_AUTHENTICATOR="SNOWFLAKE_JWT"

CONN="ci"

# -----------------------------------------------------------------------------
# 2. PR用データDBをzero-copy cloneで作成
# -----------------------------------------------------------------------------
echo ""
echo "[CI] (1/5) Cloning PROD_DB → ${PR_DB} (zero-copy)..."
snow sql -c "$CONN" -q "
CREATE OR REPLACE DATABASE ${PR_DB} CLONE PROD_DB;
GRANT ALL ON DATABASE ${PR_DB} TO ROLE CI_ROLE;
"

# -----------------------------------------------------------------------------
# 3. Git Repository から PRブランチを fetch
# -----------------------------------------------------------------------------
echo "[CI] (2/5) Fetching PR branch from Git repository..."
snow sql -c "$CONN" -q "ALTER GIT REPOSITORY PROD_DBT_DB.INTEGRATIONS.DBT_REPO FETCH;"

# -----------------------------------------------------------------------------
# 4. PR用 dbt project object を作成 (or 置き換え)
# -----------------------------------------------------------------------------
echo "[CI] (3/5) Creating DBT PROJECT object for PR..."
snow sql -c "$CONN" -q "
CREATE OR REPLACE DBT PROJECT ${PROJECT_FQN}
    FROM '@PROD_DBT_DB.INTEGRATIONS.DBT_REPO/branches/${GIT_BRANCH_NAME}/dbt_project/'
    EXTERNAL_ACCESS_INTEGRATIONS = (dbt_packages_eai)
    COMMENT = 'PR #${PR_NUMBER} CI';
"

# -----------------------------------------------------------------------------
# 5. dbt build を実行 (PR_<番号>_DB にデータ書き込み)
# -----------------------------------------------------------------------------
echo "[CI] (4/5) Executing dbt build..."
# vars で target_database を上書き、profiles.yml の ci targetが使われる
BUILD_QUERY_ID=$(snow sql -c "$CONN" -q "
EXECUTE DBT PROJECT ${PROJECT_FQN}
    ARGS='build --target ci --vars \"{target_database: ${PR_DB}, pr_number: ${PR_NUMBER}}\" --fail-fast';
" --format json | python3 -c "import sys, json; print(json.load(sys.stdin)[-1].get('queryId', ''))" 2>/dev/null || echo "")

# -----------------------------------------------------------------------------
# 6. ログ取得 (失敗時のデバッグ用)
# -----------------------------------------------------------------------------
echo "[CI] (5/5) Retrieving dbt logs..."
if [ -n "${BUILD_QUERY_ID}" ]; then
    snow sql -c "$CONN" -q "SELECT SYSTEM\$GET_DBT_LOG('${BUILD_QUERY_ID}');" || true
fi

echo ""
echo "===================================="
echo "[CI] ✅ PR #${PR_NUMBER} build complete"
echo "===================================="
echo ""
echo "Cleanup will happen on PR close (.gitbucket/teardown.yml)"
