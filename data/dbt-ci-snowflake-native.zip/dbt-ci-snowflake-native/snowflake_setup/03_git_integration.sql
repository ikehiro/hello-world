-- =============================================================================
-- 03_git_integration.sql
-- Phase 1: GitBucket連携 (API Integration + Git Repository)
--
-- 前提:
--   - GitBucketで dbt-project リポジトリが存在
--   - GitBucket Personal Access Token を発行済み
-- =============================================================================
USE ROLE ACCOUNTADMIN;

-- -----------------------------------------------------------------------------
-- GitBucket認証情報をSnowflake Secretとして保管
-- -----------------------------------------------------------------------------
USE DATABASE PROD_DBT_DB;
USE SCHEMA INTEGRATIONS;

CREATE OR REPLACE SECRET gitbucket_secret
    TYPE = PASSWORD
    USERNAME = 'ikeda'                              -- ★ GitBucketユーザー名
    PASSWORD = 'PASTE_GITBUCKET_PERSONAL_TOKEN';    -- ★ Personal Access Token

-- -----------------------------------------------------------------------------
-- API Integration (Snowflakeから外部Gitサーバーへの接続を許可)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE API INTEGRATION gitbucket_api_integration
    API_PROVIDER = git_https_api
    API_ALLOWED_PREFIXES = ('https://gitbucket.example.com/ikeda/')  -- ★ 実URL
    ALLOWED_AUTHENTICATION_SECRETS = (PROD_DBT_DB.INTEGRATIONS.gitbucket_secret)
    ENABLED = TRUE
    COMMENT = 'GitBucketとの連携用';

-- 利用権限をDBT_PROD_ROLEに付与
GRANT USAGE ON INTEGRATION gitbucket_api_integration TO ROLE DBT_PROD_ROLE;
GRANT USAGE ON SECRET PROD_DBT_DB.INTEGRATIONS.gitbucket_secret TO ROLE DBT_PROD_ROLE;
GRANT READ ON SECRET PROD_DBT_DB.INTEGRATIONS.gitbucket_secret TO ROLE DBT_PROD_ROLE;

-- -----------------------------------------------------------------------------
-- Git Repository オブジェクト
-- -----------------------------------------------------------------------------
USE ROLE DBT_PROD_ROLE;

CREATE OR REPLACE GIT REPOSITORY PROD_DBT_DB.INTEGRATIONS.DBT_REPO
    API_INTEGRATION = gitbucket_api_integration
    GIT_CREDENTIALS = PROD_DBT_DB.INTEGRATIONS.gitbucket_secret
    ORIGIN = 'https://gitbucket.example.com/ikeda/dbt-project.git'  -- ★ 実URL
    COMMENT = 'dbt projectのソースリポジトリ';

-- 初回fetch (mainブランチを取得)
ALTER GIT REPOSITORY PROD_DBT_DB.INTEGRATIONS.DBT_REPO FETCH;

-- 確認: ブランチ一覧
SHOW GIT BRANCHES IN PROD_DBT_DB.INTEGRATIONS.DBT_REPO;
