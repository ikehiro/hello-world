-- =============================================================================
-- 05_ci_database.sql
-- Phase 2: CI用環境
--
-- 設計:
--   - CI用 dbt project object の置き場: CI_DBT_DB.PR_OBJECTS
--   - PR用データDBは動的に作成 (PR_<番号>_DB)
--   - CI用WHは XSmallで自動停止短め (コスト最小化)
-- =============================================================================
USE ROLE SYSADMIN;

CREATE DATABASE IF NOT EXISTS CI_DBT_DB
    COMMENT = 'CI用dbt project objectの置き場';

CREATE SCHEMA IF NOT EXISTS CI_DBT_DB.PR_OBJECTS
    COMMENT = 'PR単位のdbt project object';

CREATE SCHEMA IF NOT EXISTS CI_DBT_DB.INTEGRATIONS
    COMMENT = 'CI用の共有オブジェクト';

CREATE WAREHOUSE IF NOT EXISTS CI_WH WITH
    WAREHOUSE_SIZE = 'XSMALL'
    AUTO_SUSPEND = 30           -- 30秒で自動停止
    AUTO_RESUME = TRUE
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'CI実行用 (コスト最小化)';

-- CI用リソースモニター (月次クレジット上限)
USE ROLE ACCOUNTADMIN;
CREATE RESOURCE MONITOR IF NOT EXISTS CI_MONITOR WITH
    CREDIT_QUOTA = 50               -- 月50クレジットを上限 (要調整)
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    TRIGGERS
        ON 80 PERCENT DO NOTIFY
        ON 100 PERCENT DO SUSPEND;

ALTER WAREHOUSE CI_WH SET RESOURCE_MONITOR = CI_MONITOR;
