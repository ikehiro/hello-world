-- =============================================================================
-- 06_ci_roles.sql
-- Phase 2: CI用ロール
--
-- 権限ポリシー:
--   - CI_DBT_DB: 全権限 (project objectの作成・削除)
--   - PR_*_DB: 作成・削除権限 (動的に作るので、ACCOUNT全体のCREATE DATABASE権限要)
--   - PROD_DB: SELECTのみ (--defer用)
-- =============================================================================
USE ROLE SECURITYADMIN;
CREATE ROLE IF NOT EXISTS CI_ROLE
    COMMENT = 'CI実行用ロール (PR単位の検証)';

-- -----------------------------------------------------------------------------
-- CI_DBT_DB への権限 (dbt project objectを作る場所)
-- -----------------------------------------------------------------------------
USE ROLE SYSADMIN;
GRANT USAGE ON DATABASE CI_DBT_DB TO ROLE CI_ROLE;
GRANT USAGE ON ALL SCHEMAS IN DATABASE CI_DBT_DB TO ROLE CI_ROLE;
GRANT ALL ON SCHEMA CI_DBT_DB.PR_OBJECTS TO ROLE CI_ROLE;
GRANT USAGE ON WAREHOUSE CI_WH TO ROLE CI_ROLE;

-- -----------------------------------------------------------------------------
-- PR_*_DB を動的作成するための権限
-- -----------------------------------------------------------------------------
USE ROLE ACCOUNTADMIN;
GRANT CREATE DATABASE ON ACCOUNT TO ROLE CI_ROLE;

-- -----------------------------------------------------------------------------
-- PROD_DB への参照権 (Slim CI / --defer 用)
-- -----------------------------------------------------------------------------
USE ROLE SYSADMIN;
GRANT USAGE ON DATABASE PROD_DB TO ROLE CI_ROLE;
GRANT USAGE ON ALL SCHEMAS IN DATABASE PROD_DB TO ROLE CI_ROLE;
GRANT USAGE ON FUTURE SCHEMAS IN DATABASE PROD_DB TO ROLE CI_ROLE;
GRANT SELECT ON ALL TABLES IN DATABASE PROD_DB TO ROLE CI_ROLE;
GRANT SELECT ON FUTURE TABLES IN DATABASE PROD_DB TO ROLE CI_ROLE;
GRANT SELECT ON ALL VIEWS IN DATABASE PROD_DB TO ROLE CI_ROLE;
GRANT SELECT ON FUTURE VIEWS IN DATABASE PROD_DB TO ROLE CI_ROLE;

-- -----------------------------------------------------------------------------
-- Git Integration を CI でも使う
-- -----------------------------------------------------------------------------
USE ROLE ACCOUNTADMIN;
GRANT USAGE ON INTEGRATION gitbucket_api_integration TO ROLE CI_ROLE;
GRANT USAGE ON SECRET PROD_DBT_DB.INTEGRATIONS.gitbucket_secret TO ROLE CI_ROLE;
GRANT READ ON SECRET PROD_DBT_DB.INTEGRATIONS.gitbucket_secret TO ROLE CI_ROLE;
GRANT USAGE ON INTEGRATION dbt_packages_eai TO ROLE CI_ROLE;

-- Git Repository本体へのアクセス
USE ROLE SYSADMIN;
GRANT USAGE ON DATABASE PROD_DBT_DB TO ROLE CI_ROLE;
GRANT USAGE ON SCHEMA PROD_DBT_DB.INTEGRATIONS TO ROLE CI_ROLE;
GRANT READ ON GIT REPOSITORY PROD_DBT_DB.INTEGRATIONS.DBT_REPO TO ROLE CI_ROLE;

-- -----------------------------------------------------------------------------
-- CIサービスアカウント
-- -----------------------------------------------------------------------------
USE ROLE USERADMIN;
CREATE USER IF NOT EXISTS DBT_CI_USER
    RSA_PUBLIC_KEY = 'PASTE_CI_PUBLIC_KEY_HERE'  -- ★ CI用の別鍵を生成して登録
    DEFAULT_ROLE = CI_ROLE
    DEFAULT_WAREHOUSE = CI_WH
    COMMENT = 'CI実行用サービスアカウント';

USE ROLE SECURITYADMIN;
GRANT ROLE CI_ROLE TO USER DBT_CI_USER;
