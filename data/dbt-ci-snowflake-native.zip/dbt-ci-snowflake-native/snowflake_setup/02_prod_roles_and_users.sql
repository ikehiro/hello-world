-- =============================================================================
-- 02_prod_roles_and_users.sql
-- Phase 1: 本番ロール体系
--
-- 3層ロール構造 (Snowflake標準パターン):
--   FUNCTIONAL ROLES → ACCESS ROLES → SYSTEM (Snowflake組み込み)
--
--   DBT_PROD_ROLE (functional) 
--     → PROD_DB_RW (access role, データ読み書き)
--     → PROD_DBT_DB_RW (access role, dbt project定義の読み書き)
-- =============================================================================
USE ROLE SECURITYADMIN;

-- -----------------------------------------------------------------------------
-- Access Roles (リソース単位の権限を持つ)
-- -----------------------------------------------------------------------------
CREATE ROLE IF NOT EXISTS PROD_DB_RW
    COMMENT = 'PROD_DBの読み書き権限';

CREATE ROLE IF NOT EXISTS PROD_DBT_DB_RW
    COMMENT = 'PROD_DBT_DBの読み書き権限 (dbt project objects管理)';

USE ROLE SYSADMIN;
GRANT USAGE ON DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT USAGE ON ALL SCHEMAS IN DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT USAGE ON FUTURE SCHEMAS IN DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT ALL ON ALL SCHEMAS IN DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT ALL ON FUTURE SCHEMAS IN DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON FUTURE TABLES IN DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT SELECT ON ALL VIEWS IN DATABASE PROD_DB TO ROLE PROD_DB_RW;
GRANT SELECT ON FUTURE VIEWS IN DATABASE PROD_DB TO ROLE PROD_DB_RW;

GRANT USAGE ON DATABASE PROD_DBT_DB TO ROLE PROD_DBT_DB_RW;
GRANT USAGE ON ALL SCHEMAS IN DATABASE PROD_DBT_DB TO ROLE PROD_DBT_DB_RW;
GRANT USAGE ON FUTURE SCHEMAS IN DATABASE PROD_DBT_DB TO ROLE PROD_DBT_DB_RW;
GRANT ALL ON ALL SCHEMAS IN DATABASE PROD_DBT_DB TO ROLE PROD_DBT_DB_RW;
GRANT ALL ON FUTURE SCHEMAS IN DATABASE PROD_DBT_DB TO ROLE PROD_DBT_DB_RW;

-- -----------------------------------------------------------------------------
-- Functional Role (利用目的単位)
-- -----------------------------------------------------------------------------
USE ROLE SECURITYADMIN;
CREATE ROLE IF NOT EXISTS DBT_PROD_ROLE
    COMMENT = '本番dbt実行用ロール';

GRANT ROLE PROD_DB_RW       TO ROLE DBT_PROD_ROLE;
GRANT ROLE PROD_DBT_DB_RW   TO ROLE DBT_PROD_ROLE;
GRANT USAGE ON WAREHOUSE PROD_WH TO ROLE DBT_PROD_ROLE;

-- -----------------------------------------------------------------------------
-- 本番デプロイユーザー (Key pair認証)
-- -----------------------------------------------------------------------------
USE ROLE USERADMIN;
CREATE USER IF NOT EXISTS DBT_PROD_USER
    -- 事前に以下で鍵生成しておく:
    --   openssl genrsa 2048 | openssl pkcs8 -topk8 -inform PEM -out rsa_key.p8 -nocrypt
    --   openssl rsa -in rsa_key.p8 -pubout -out rsa_key.pub
    RSA_PUBLIC_KEY = 'PASTE_YOUR_PUBLIC_KEY_HERE'  -- ★ 公開鍵を貼る
    DEFAULT_ROLE = DBT_PROD_ROLE
    DEFAULT_WAREHOUSE = PROD_WH
    COMMENT = '本番dbt実行用サービスアカウント';

USE ROLE SECURITYADMIN;
GRANT ROLE DBT_PROD_ROLE TO USER DBT_PROD_USER;

-- 確認
SHOW ROLES LIKE '%DBT%';
SHOW GRANTS TO ROLE DBT_PROD_ROLE;
