-- =============================================================================
-- 04_external_access.sql
-- Phase 1: dbt deps で外部パッケージを取得するためのExternal Access設定
--
-- 注意:
--   packages.yml で dbt-labs/dbt_utils 等を利用する場合、deploy時に
--   EXTERNAL_ACCESS_INTEGRATIONS を指定することで自動的にdbt depsが走る。
--   この設定がないと、dbt_packages を手動で含めてデプロイする必要あり。
-- =============================================================================
USE ROLE ACCOUNTADMIN;

-- -----------------------------------------------------------------------------
-- Network Rule (許可する外部URL)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE NETWORK RULE PROD_DBT_DB.INTEGRATIONS.dbt_packages_network_rule
    MODE = EGRESS
    TYPE = HOST_PORT
    VALUE_LIST = (
        'codeload.github.com',     -- dbt-labs等のパッケージ取得元
        'github.com',
        'hub.getdbt.com'           -- dbt hub
    );

-- -----------------------------------------------------------------------------
-- External Access Integration
-- -----------------------------------------------------------------------------
CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION dbt_packages_eai
    ALLOWED_NETWORK_RULES = (PROD_DBT_DB.INTEGRATIONS.dbt_packages_network_rule)
    ENABLED = TRUE
    COMMENT = 'dbt deps用外部アクセス';

GRANT USAGE ON INTEGRATION dbt_packages_eai TO ROLE DBT_PROD_ROLE;
