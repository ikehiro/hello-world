-- =============================================================================
-- 01_prod_database.sql
-- Phase 1: 本番のデータベース・スキーマを作成
--
-- 設計方針:
--   - データの実体は PROD_DB
--   - dbt project object の置き場は別DB (PROD_DBT_DB) に分離
--   - これにより「定義」と「データ」を独立してバックアップ・権限管理可能
-- =============================================================================
USE ROLE SYSADMIN;

-- -----------------------------------------------------------------------------
-- データ実体のDB
-- -----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS PROD_DB
    COMMENT = '本番データウェアハウス (RAW/STG/MART)';

CREATE SCHEMA IF NOT EXISTS PROD_DB.RAW       COMMENT = '取り込み生データ';
CREATE SCHEMA IF NOT EXISTS PROD_DB.STAGING   COMMENT = 'ステージング層';
CREATE SCHEMA IF NOT EXISTS PROD_DB.MARTS     COMMENT = 'マート層';

-- -----------------------------------------------------------------------------
-- dbt project object の置き場
-- -----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS PROD_DBT_DB
    COMMENT = 'dbt project objectの定義置き場 (本番)';

CREATE SCHEMA IF NOT EXISTS PROD_DBT_DB.DEPLOYMENTS
    COMMENT = '本番にデプロイされたdbt projectオブジェクト';

CREATE SCHEMA IF NOT EXISTS PROD_DBT_DB.INTEGRATIONS
    COMMENT = 'Git Integration等の共有オブジェクト';

-- -----------------------------------------------------------------------------
-- 本番用ウェアハウス
-- -----------------------------------------------------------------------------
CREATE WAREHOUSE IF NOT EXISTS PROD_WH WITH
    WAREHOUSE_SIZE = 'MEDIUM'
    AUTO_SUSPEND = 60
    AUTO_RESUME = TRUE
    INITIALLY_SUSPENDED = TRUE
    COMMENT = '本番dbt実行用';

-- 確認
SHOW DATABASES LIKE 'PROD%';
SHOW WAREHOUSES LIKE 'PROD%';
